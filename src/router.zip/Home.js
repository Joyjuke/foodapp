const Home = () => {
  return (
    <div>
      <h1>홈</h1>
      <p>홈, 그페이지는 가장 먼저 보여지는 페이지.</p>
    </div>
  );
};

export default Home;
